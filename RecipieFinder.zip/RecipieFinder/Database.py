#Importing
import json
from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin, current_user, login_required
#from sqlalchemy.orm import relationship
import requests
import re
import jsonify

#Linking db with Flask /Users/GOD/Desktop/school/447/RecipieFinder/RecipieFinder/RecipieFinder
app = Flask(__name__, template_folder= ".", static_folder='static', static_url_path='/static')
app.secret_key = 'secret'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///CMSC447Project_new5.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']= False
#Initialize the database
db = SQLAlchemy(app)

def get_recipe_id(url):
    # Use regular expression to extract the id after "recipe_"
    match = re.search(r'recipe_(\w+)$', url)
    recipe_id = match.group(1)
    return recipe_id

def find_recipes(id):
    # API endpoint URL
    url = "https://api.edamam.com/api/recipes/v2/"
    url+= id
    # API credentials
    app_id = "dd3e08d9"
    app_key = "db6b2a58e06f801203d035f5914b6877"

    # Search parameters
    params = {
        "type": "public",
        "app_id": app_id,
        "app_key": app_key,
    }

    # Make the API request
    response = requests.get(url, params=params)
    recipes = response.json()
    return recipes

def get_recipes(query, cuisineType= None, mealType= None, dishType=None, diet= None, health= None, random= False):
    # API endpoint URL
    url = "https://api.edamam.com/api/recipes/v2"

    # API credentials
    app_id = "4e1c4b9e"
    app_key = "c07ac735f49f7a715321d4fe7f5e71de"

    # Search parameters
    params = {
        "type": "public",
        "app_id": app_id,
        "app_key": app_key,
        "mealType": mealType,
        "dishType": dishType,
        'diet': diet,
        'health': health,
        'cuisineType': cuisineType,
        'random': random,
        'q': query
    }

    # Make the API request
    response = requests.get(url, params=params)
    recipes=[]
    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Process the response data (e.g., convert to JSON, print results)
        recipes = response.json()
    else:
        # Print an error message if the request was not successful
        print(f"Error: {response.status_code}")
    return recipes

#All five classes for our data base
class User(db.Model):
    user_id = db.Column(db.Integer, primary_key=True)
    user_name = db.Column(db.String(50), nullable= False)
    user_password = db.Column(db.String(255))

    def __repr__(self):
        return '<Name %r' %self.user_name

class Recipes(db.Model):
    recipe_id = db.Column(db.Integer, primary_key=True)
    recipe_name = db.Column(db.String(50), nullable= False)
    #ingred_array = db.Column(db.String)#ingredients seperate by commas
    time_of_day = db.Column(db.String(50), nullable= False)
    
    def __repr__(self):
        return '<Name %r' %self.recipe_name

   
class login_status(db.Model):
    id = db.Column(db.Integer, primary_key=True)# Define a primary key
    user_id = db.Column(db.Integer, db.ForeignKey('user.user_id'))
    login= db.Column(db.Boolean, nullable= False)

class Favorites(db.Model):
    id = db.Column(db.Integer, primary_key=True)# Define a primary key
    user_id = db.Column(db.Integer, db.ForeignKey('user.user_id'))
    recipe_name =  db.Column(db.Integer, db.ForeignKey('recipes.recipe_name'))
    # fav_ingred_array = db.Column(db.String)#ingredients seperated by commas
    def __repr__(self):
      return f"Favorites(user_id={self.user_id},recipe_name= {self.recipe_name})"
    
@app.route('/')
def home():
    login = session.get('login', False)
    user= session.get('user', None)
    return render_template('index.html', login= login)

@app.route('/signup')
def signup():
    return render_template('signup.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/breakfast')
def breakfast():
    login = session.get('login', False)
    user= session.get('user', None)
    return render_template('breakfast.html')

@app.route('/search', methods= ['POST'])
def Search():
  # Get user input from the form
  search= request.form.get('search')
  cuisinetype= request.form.get('cuisineType')
  mealType = request.form.get('mealType')
  # Check if cuisineType and mealType are set to "None" and convert them to None
  if cuisinetype== "None":
    cuisinetype= None
  if mealType== "None":
     mealType= None
  # Call the get_recipes function to retrieve recipe information based on user input
  
  recipes= get_recipes(search, cuisineType= cuisinetype, mealType= mealType)
  # Process the API response to extract relevant information
  ret= []
  for i in range(len(recipes.get('hits'))):
    name= recipes.get('hits')[i].get('recipe').get('label')
    ingredients= recipes.get('hits')[i].get('recipe').get('ingredients')
    image= recipes.get('hits')[i].get('recipe').get('image')
    id= get_recipe_id(recipes.get('hits')[i].get('recipe').get('uri'))
    ret.append([name, ingredients, image, id])
  # Get login status and user information from the session
  login = session.get('login', False)
  user= session.get('user', None)
  # Render the 'search.html' template with the obtained results and user information
  return render_template('/search.html', results= ret, login = login, user = user)

@app.route('/breakfast', methods= ['POST'])
def breakfast_search():
  # Get user input from the form
  search= request.form.get('search')
  cuisinetype= request.form.get('cuisineType')
  mealType = request.form.get('mealType')

  # Check if cuisineType and mealType are set to "None" and convert them to None
  if cuisinetype== "None":
    cuisinetype= None
  if mealType== "None":
     mealType= None
  # Call the get_recipes function to retrieve recipe information based on user input
  recipes= get_recipes(search, cuisineType= cuisinetype, mealType= mealType)
  ret= []
  for i in range(len(recipes.get('hits'))):
    name= recipes.get('hits')[i].get('recipe').get('label')
    ingredients= recipes.get('hits')[i].get('recipe').get('ingredients')
    image= recipes.get('hits')[i].get('recipe').get('image')
    id= get_recipe_id(recipes.get('hits')[i].get('recipe').get('uri'))
    ret.append([name, ingredients, image, id])

  # Get login status and user information from the session
  login = session.get('login', False)
  user= session.get('user', None)
  # Render the 'search.html' template with the obtained results and user information
  return render_template('/breakfast.html', results= ret, login = login, user = user)


@app.route('/recipe_detail/<string:recipe_id>')
def recipe_detail(recipe_id):
    # Fetch recipe details based on recipe_name from the database or API
  recipe = find_recipes(recipe_id)
  name= recipe.get('recipe').get('label')
  ingredients= recipe.get('recipe').get('ingredients')
  image= recipe.get('recipe').get('image')
  calories= recipe.get('recipe').get('calories')
  mealType=recipe.get('recipe').get('mealType')
  dishType= recipe.get('recipe').get('dishType')
  dietLabels= recipe.get('recipe').get('dietLabels')
  healthLabels= recipe.get('recipe').get('healthLabels')
  url=  recipe.get('recipe').get('url')
  instructionLines= recipe.get('recipe').get('instructionLines')
  totalTime=recipe.get('recipe').get('totalTime')
  totalNutrients= recipe.get('recipe').get('totalNutrients')

  # Create a dictionary with recipe details for rendering in the template
  recipe_details = {
    'recipe_name': name,
    'ingredients': ingredients,
    'image': image,
    'calories': round(calories),
    'mealType': mealType,
    'dishType': dishType,
    'dietLabels': dietLabels,
    'healthLabels': healthLabels,
    'url': url,
    'instructionLines': instructionLines,
    'totalTime':totalTime,
    'totalNutrients':totalNutrients
  }
  # Render the 'recipe_detail.html' template with the obtained recipe details
  return render_template('recipe_detail.html', recipe=recipe_details)


@app.route('/search')
def search():
    return render_template('search.html')

@app.route('/login', methods=['GET'])
def login():
    return render_template('login.html')

@app.route('/logout')
def logout():
   session['login']= False
   session['user']= None
   return redirect(url_for('home'))


@app.route('/save_favorite', methods=['POST'])
def save_favorite():
  # Retrieve all users from the database
  users= User.query.all()
  # Initialize user ID and login status variables
  Uid = -1
  login= False
  # Find the user ID of the current session user
  for user in users:
    if user.user_name == session['user']:
       Uid = user.user_id
  # Get the recipe ID from the form data
  recipe_id = request.form.get('recipe_id')

  # Create a new Favorites instance and add it to the database
  fav1 = Favorites(user_id= Uid, recipe_name = recipe_id)
  db.session.add(fav1)
  db.session.commit()
  # Print information for debugging purposes
  print(f"Username: {Uid}, recipe_name: {recipe_id}")
  # Redirect to the 'saved' route
  return redirect(url_for('saved'))


@app.route('/favorites', methods=['POST'])
def Remove_favorite():
    # Get the recipe ID to remove from the form data
    fav_name = request.form['favorite_id']
    # Query the database to find the Favorite with the specified recipe ID
    favorite_to_remove = Favorites.query.filter_by(recipe_name=fav_name).first()
    # Print the recipe ID for debugging purposes
    print("This is", fav_name)
    # Check if the favorite exists and remove it from the database
    if favorite_to_remove:
        db.session.delete(favorite_to_remove)
        db.session.commit()
        print("Item has been successfully removed")
    else:
        print("Favorite not found")
    # Redirect to the 'saved' route
    return redirect(url_for('saved'))


@app.route('/forgot_password', methods=['POST'])
def reset_password():
  # Check if the request method is POST
  if request.method == 'POST':
    # Get user input from the form
    email= request.form['email']
    password1= request.form['password1']
    password2= request.form['password2']
    print(f"Email: {email}, Password1: {password1}, Password2: {password2}")
    
    # Query the database to find users with the specified email
    users = User.query.filter_by(user_name = email).all()
    # Check if the email is not in the database
    if not users: #email not within database
      flash("Email not in database")
      print("Email not in database")
      return redirect(url_for('signup'))
    # Retrieve the first user with the specified email
    user = users[0]
    # Check if the entered passwords match
    if password1 != password2:
      flash("Passwords do not match")
      print("Passwords do not match")
      return redirect(url_for('forgot_password'))
    #updatepassword in database
    user.user_password = password1
    db.session.commit()
    # Display a flash message and print confirmation
    flash("Password has been reset")
    print("Password has been reset")
    # Redirect to the 'login' route
  return redirect(url_for('login'))



@app.route('/signup', methods=['POST'])
def signup_submit():
  # Check if the request method is POST
  if request.method == 'POST':
    # Get user input from the form
    email= request.form['email']
    password= request.form['password']
    print(f"Email: {email}, Password: {password}")
    # Query the database to retrieve all users
    users= User.query.all()
    # Check if the entered email already exists in the database
    for user in users:
      if user.user_name== email:
        print(email)
        print(user.user_name)
        print("User already Exists")
        return redirect(url_for('home'))
    # If the email does not exist, add the new user to the database  
    print(f"Email: {email}, Password: {password}")
    print("Adding user to database")
    sign_up = User( user_name = email, user_password = password)
    db.session.add(sign_up)
    db.session.commit()
  # Redirect to the 'login' route
  return redirect(url_for('login'))

@app.route('/login', methods=['POST'])
def login_submit():
  # Check if the request method is POST
  if request.method == 'POST':
    # Get user input from the form
    email= request.form['email']
    password= request.form['password']
    print(f"Email: {email}, Password: {password}")

    # Query the database to retrieve all users
    users= User.query.all()
    # Initialize login status variable
    login= False

    # Check if the entered email corresponds to a user in the database
    for user in users:
      if user.user_name == email:
         # Check if the entered password is correct
         if user.user_password != password:#incorrect password
            print("Username correct but password incorrect")
         # If both username and password are correct, set session variables and redirect 
         if user.user_name== email and user.user_password== password:#correct user and password
            print("user found, and password is correct")
            session['login']= True
            session['user'] = user.user_name
            login = session.get('login')
            user= session.get('user')   
            return redirect(url_for('saved', login= login))
  # If the username is not found, set login status to False and user to None
  print("User not found")#username not found
  session['login']= False
  session['user']= None
  # Render the 'login.html' template
  return render_template('login.html')

@app.route('/favorites')
def saved():
 
  # Retrieve all users from the database
  users= User.query.all()
  # Initialize user ID and login status variables
  Uid = -1
  login= False
  # Find the user ID of the current session user
  for user in users:
    if user.user_name == session['user']:
       Uid = user.user_id
  
  # Print the user ID for debugging purposes
  print(f"Uid:{Uid}")
  # Retrieve all favorites from the database
  fav= Favorites.query.all()
  results = []
  # Iterate through the favorites and add relevant details to the results list
  for favor in fav:
     if favor.user_id ==  Uid:
        recipe= find_recipes(favor.recipe_name)
        name= recipe.get('recipe').get('label')
        ingredients= recipe.get('recipe').get('ingredients')
        image= recipe.get('recipe').get('image')
        recipe_id= favor.recipe_name
        results.append([name, ingredients, image, recipe_id])

  # Render the 'favorites.html' template with the obtained results
  return render_template('favorites.html', favorites= results)

@app.route('/forgot_password')
def forgot_password():
    return render_template('fpsswd.html')

if __name__== "__main__":
  with app.app_context():
   
    db.create_all()
  app.run(debug=True)